from website import create_app

app = create_app()

if(__name__== '__main__'):

    app.run() # running website in debug mode (any change will be immediately implemented)









